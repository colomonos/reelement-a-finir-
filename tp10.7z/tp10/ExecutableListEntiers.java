
import java.util.Collections;
import java.util.NoSuchElementException;

public class ExecutableListEntiers {
    public static void main(String[] args) {
        ListEntiers list = new ListEntiers();
        list.remplir();

        try{
            Collections.min(list);
        }

        catch (NoSuchElementException x) {

            System.out.println("”Il n’y a pas de minimum :");

        }
        
        Collections.max(list);
    
}
}