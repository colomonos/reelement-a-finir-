import java.util.List;
import java.util.ArrayList;
import java.lang.Math;

public class ListEntiers extends ArrayList<Integer>{

    public ListEntiers(){
        super();
    }
    
    
/**remplissageliste*/
public void remplir(){

int nb=(int) (Math.random()*10);
    for(int i=0;i<nb;++i){

     this.add((int)(Math.random()*50));
    }

    
    
}


/**getter*/
public List<Integer> getEntiers(){

    return this ;
}

@Override
public  String toString(){

return this.toString();

}




}

